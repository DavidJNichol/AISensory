﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Aspect : MonoBehaviour
{
    public enum aspect
    {
        Player,
        Enemy
    }
    public aspect aspectName;
}